function hoverfx() {
    hover.play();
}
function hoverchanelfx1() {
    hoverchannel.play();
    hover.play();
    channellabel1.style.display = "inline-grid";
}

function killlabel1() {
    channellabel1.style.display = "none";
}
function hoverchanelfx2() {
    hoverchannel.play();
    hover.play();
    channellabel2.style.display = "inline-grid";
}

function killlabel2() {
    channellabel2.style.display = "none";
}

function hoverchanelfx3() {
    hoverchannel.play();
    hover.play();
    channellabel3.style.display = "inline-grid";
}

function killlabel3() {
    channellabel3.style.display = "none";
}

function hoverchanelfx4() {
    hoverchannel.play();
    hover.play();
    channellabel4.style.display = "inline-grid";
}

function killlabel4() {
    channellabel4.style.display = "none";
}

function hoverchanelfx5() {
    hoverchannel.play();
    hover.play();
    channellabel5.style.display = "inline-grid";
}

function killlabel5() {
    channellabel5.style.display = "none";
}

function hoverchanelfx6() {
    hoverchannel.play();
    hover.play();
    channellabel6.style.display = "inline-grid";
}

function killlabel6() {
    channellabel6.style.display = "none";
}

function hoverchanelfx7() {
    hoverchannel.play();
    hover.play();
    channellabel7.style.display = "inline-grid";
}

function killlabel7() {
    channellabel7.style.display = "none";
}

function hoverchanelfx8() {
    hoverchannel.play();
    hover.play();
    channellabel8.style.display = "inline-grid";
}

function killlabel8() {
    channellabel8.style.display = "none";
}

function hoverchanelfx9() {
    hoverchannel.play();
    hover.play();
    channellabel9.style.display = "inline-grid";
}

function killlabel9() {
    channellabel9.style.display = "none";
}

function hoverchanelfx10() {
    hoverchannel.play();
    hover.play();
    channellabel10.style.display = "inline-grid";
}

function killlabel10() {
    channellabel10.style.display = "none";
}

function hoverchanelfx11() {
    hoverchannel.play();
    hover.play();
    channellabel11.style.display = "inline-grid";
}

function killlabel11() {
    channellabel11.style.display = "none";
}

function hoverchanelfx12() {
    hoverchannel.play();
    hover.play();
    channellabel12.style.display = "inline-grid";
}

function killlabel12() {
    channellabel12.style.display = "none";
}